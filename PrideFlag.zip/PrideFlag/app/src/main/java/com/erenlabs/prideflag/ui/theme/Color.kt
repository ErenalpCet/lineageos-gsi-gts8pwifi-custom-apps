package com.erenlabs.prideflag.ui.theme

import androidx.compose.ui.graphics.Color

val PrideRed = Color(0xFFE40303)
val PrideOrange = Color(0xFFFF8C00)
val PrideYellow = Color(0xFFFFED00)
val PrideGreen = Color(0xFF008026)
val PrideBlue = Color(0xFF24408E)
val PrideViolet = Color(0xFF732982)
