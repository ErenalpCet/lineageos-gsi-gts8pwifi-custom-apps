package com.erenlabs.prideflag

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.erenlabs.prideflag.ui.theme.PrideBlue
import com.erenlabs.prideflag.ui.theme.PrideFlagTheme
import com.erenlabs.prideflag.ui.theme.PrideGreen
import com.erenlabs.prideflag.ui.theme.PrideOrange
import com.erenlabs.prideflag.ui.theme.PrideRed
import com.erenlabs.prideflag.ui.theme.PrideViolet
import com.erenlabs.prideflag.ui.theme.PrideYellow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PrideFlagTheme {
                PrideFlagScreen()
            }
        }
    }
}

@Composable
fun PrideFlagScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BasicText(
                text = "Love is Love",
                style = TextStyle(
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                ),
                modifier = Modifier.padding(vertical = 32.dp)
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                val flagColors = listOf(
                    PrideRed,
                    PrideOrange,
                    PrideYellow,
                    PrideGreen,
                    PrideBlue,
                    PrideViolet,
                )

                flagColors.forEach { color ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(color)
                    )
                }
            }

            BasicText(
                text = "Build by ErenalpCet",
                style = TextStyle(
                    fontSize = 16.sp,
                    color = Color.Black
                ),
                modifier = Modifier.padding(vertical = 16.dp)
            )
        }
    }
}

@Composable
fun BasicText(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier
) {
    androidx.compose.foundation.text.BasicText(
        text = text,
        style = style,
        modifier = modifier
    )
}
