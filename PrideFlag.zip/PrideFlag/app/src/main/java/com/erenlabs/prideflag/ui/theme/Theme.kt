package com.erenlabs.prideflag.ui.theme

import androidx.compose.runtime.Composable

@Composable
fun PrideFlagTheme(
    content: @Composable () -> Unit
) {
    content()
}
